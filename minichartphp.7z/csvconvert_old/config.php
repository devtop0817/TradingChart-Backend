<?php
$default_last_updated_date = '0000-00-00';

// insert CSV files Directory full PATH.

$directory=array(
	 'NASD_2017'=>'C:\inetpub\ftproot\NASD\NASD_2017',

);
?>