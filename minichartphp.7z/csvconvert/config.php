<?php
$default_last_updated_date = '0000-00-00';

// insert CSV files Directory full PATH.

$directory = array(
    'SGX_2021'=>'C:\inetpub\ftproot\SGX\SGX_2021',
    'HKEX_2021'=>'C:\inetpub\ftproot\HKEX\HKEX_2021',
    'SSE_2021'=>'C:\inetpub\ftproot\SSE\SSE_2021',
    'NASD_2021'=>'C:\inetpub\ftproot\NASD\NASD_2021',
    'NYSE_2021'=>'C:\inetpub\ftproot\NYSE\NYSE_2021',
    'SZSE_2021'=>'C:\inetpub\ftproot\SZSE\SZSE_2021',
    'USEUROPE_2021'=>'C:\inetpub\ftproot\USEUROPE\USEUROPE_2021',
    'ASIA_2021'=>'C:\inetpub\ftproot\ASIA\ASIA_2021',
    'KLSE_202'=>'C:\inetpub\ftproot\KLSE\KLSE_2021',
    'FOREX_2021'=>'C:\inetpub\ftproot\FOREX\FOREX_2021',
    'ASIA_2021'=>'C:\inetpub\ftproot\ASIA\ASIA_2021'
);

$symbolesmain_path = 'C:\inetpub\ftproot\Markets';
