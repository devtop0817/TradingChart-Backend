<?php
    $_TimeCycle = 60;
    $_TableName = "TB_1monkeyladder";
?>